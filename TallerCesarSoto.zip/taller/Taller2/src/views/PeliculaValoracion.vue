<template>
	<h1>Peliculas Mejor Valoradas Por La Critica</h1>
	<h2 v-if="isLoading">Cargando...</h2>

	<section v-else class="movies-grid">
		<VistaCard
			v-for="movie in movies"
			:movie="movie"
			:onClick="MostrarPelicula"
		/>
	</section>
       <footer>
        	<container>
                <button class="buttons" @click="ultimaPagina(contador)">Pagina Anterior</button>
		        <button class="buttons" @click="siguientePagina(contador)">Siguiente Pagina</button>
            </container>
    </footer>	 
</template>

<script>
import Movie from '@/models/Movie';
import apiService from '@/services/api.service';
import VistaCard from '@/components/VistaCard.vue';
export default {
	components: {VistaCard},
	data() {
		return {
			isLoading: true,
			movies: [],
			contador: 1,
		};
	},
	mounted() {	
		this.getTopRated(1);
	},
	methods: {
		async getTopRated(currentPage) {
			this.isLoading = true;
			const { data } = await apiService.getTopRated(currentPage);
			this.movies = await Promise.all(
				data.results.map((peliculas)=> this.getMovie(peliculas.id))
			);
			this.isLoading = false;
		},
		async getMovie(PeliculaID){
			const {data} = await apiService.getMovie(PeliculaID);
			const PeliculaData = new Movie(data);
			return PeliculaData;	
		},
		MostrarPelicula(id) {
			this.$router.push({ name: 'Movie', params: { id } });
		},
		ultimaPagina(contador){
			if(contador===1){
			}else{
			this.contador=contador -1;
			return this.getTopRated(this.contador);
			}	
		},
		siguientePagina(contador){
			this.contador=contador +1;
			this.getTopRated(this.contador);	
		}
	}
};
</script>

<style>
.movies-grid {
	padding: 1rem;
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
	grid-auto-rows: 250px;
	gap: 1rem;
}

.buttons{
	border-radius: 20px;
	height: 100px;

}
</style>