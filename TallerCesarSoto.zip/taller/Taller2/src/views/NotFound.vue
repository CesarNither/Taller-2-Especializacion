<template>
	<h1>404 NotFound</h1>
</template>