<template>
	<nav id="nav">

		<router-link to="/">Inicio</router-link> |
		
    <router-link :to="{ name: 'PeliculaPopulares' }">Mas Populares</router-link>|
    <router-link to="/PeliculaValoracion">Mas Valoradas</router-link>
	</nav>

	<router-view></router-view>
</template>

<script>
export default {
	computed() {},

};
</script>

<style lang="scss">
nav {
	font-size: 2rem;
	margin-bottom: 2rem;
	text-align: center;
	padding: 0.4rem 0.6rem;
	background-color: rgb(175, 175, 175);
	color: red;
	a {
		color: black;
		text-decoration: none;
		border-bottom: 2px solid transparent;
		&.router-link-active {
			color: #c70101;
			border-bottom-color: #c70101;
		}
	}
}

#app {
	text-align: center;
	color: black;
}
</style>
