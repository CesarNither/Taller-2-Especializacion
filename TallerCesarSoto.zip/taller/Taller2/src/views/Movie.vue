<template>
	<h2 v-if="isLoading">Cargando...</h2>
	<VistaInformacionCard
		v-else
		:movie="movie"
		
		style="max-width: 400px; margin: 2rem auto"
		
	/>

</template>
<script>
import Movie from '@/models/Movie';
import apiService from '@/services/api.service';
import VistaInformacionCard from '@/components/VistaInformacionCard.vue';
export default {
	components: { VistaInformacionCard },
	beforeRouteUpdate(to, from) {
		this.movieId = to.params.id;
		this.getMovie();
	},
	data() {
		return {
			movieId: null,
			isLoading: true,
			movie: null,
		};
	},
	mounted() {
		this.movieId = this.$route.params.id;
		this.getMovie();
	},
	methods: {
		async getMovie() {
			this.isLoading = true;
			const { data } = await apiService.getMovie(this.movieId);
			this.movie = new Movie(data);
			this.isLoading = false;
		},
	},
};
</script>