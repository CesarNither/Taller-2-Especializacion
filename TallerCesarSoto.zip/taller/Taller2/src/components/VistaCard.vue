<template>
	<article class="vistaPelicula-card" :class="movie.genres[0].name" @click="onClick(movie.id)">
		<header>
			<span class="tituloPelicula">{{ movie.title }} </span>
		</header>
		<div class="contenedor">
			<img class="imagenPelicula" :src="movie.backdrop_path" />
			<div class="top-right"> &#11088;{{movie.vote_average}}</div>
		</div>
		<footer>
			<div class="generoPelicula" v-for="genero in movie.genres" :key="genero.name">
				{{ genero.name }}
			</div>
		</footer>
	</article>
</template>
<script>
export default {
	props: {
		movie: {
			type: Object,
			required: true,
		},
		onClick: {
			type: Function,
			default: () => {},
		},	
	},
};
</script>
