<template>
<article class="vistaInformacion-card">
    <span class="titulo">{{ movie.title }} </span>
</article>
<div><span class="titulo">{{ movie.original_title }} </span></div>
	<article class="vistaInformacion-card" >
		<div class="container">
			<img class="imagen" :src="movie.backdrop_path" />
            <span class="lanzamiento">Fecha de lanzamiento : {{movie.release_date}}  </span> 
		</div>
	</article>
        <h1 >Generos :</h1>
    <article class="vistaInformacion-card">
                <div>
                <div class="genero" v-for="genero in movie.genres" :key="genero.name">
				{{ genero.name }}
			</div>
        </div>
        <div class="puntuacion">
          <div>
            Puntuacion: &#11088;{{movie.vote_average}}
        </div>
        <div>
            Popularidad: {{movie.popularity}}
        </div>
        </div>
    </article>
         <h1>Sinopsis:</h1>
    <article class="vistaInformacion-card">
        <div>    
           <span class="sinopsis">{{movie.overview}}</span> 
        </div>
    </article>
</template>
<script>
export default {
	props: {
		movie: {
			type: Object,
			required: true,
		},
		onClick: {
			type: Function,
			default: () => {},
		},	
	},
};
</script>
<style></style>
